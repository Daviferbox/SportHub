// src/components/RegistroForm.jsx

import { useState } from 'react'
import NavBar from '../components/NavBar'; // Importa o NavBar
import "../styles/cadastro.css";

function RegistroForm() {

    // 1. Crie os estados para cada campo
  const [nome, setNome] = useState('');
    function handleChangeNome(evento: React.ChangeEvent<HTMLInputElement>){
        setNome(evento.target.value)
    }
    
  const [email, setEmail] = useState('');
  function handleChangeEmail(evento: React.ChangeEvent<HTMLInputElement>){
        setEmail(evento.target.value)
    }
  const [senha, setSenha] = useState('');
  function handleChangeSenha(evento: React.ChangeEvent<HTMLInputElement>){
        setSenha(evento.target.value)
    }
  const [endereco, setEndereco] = useState('');
  function handleChangeEndereco(evento: React.ChangeEvent<HTMLInputElement>){
        setEndereco(evento.target.value)
    }
  const [empresa, setEmpresa] = useState('');
  function handleChangeEmpresa(evento: React.ChangeEvent<HTMLInputElement>){
        setEmpresa(evento.target.value)
    }
  const [modalidade, setModalidade] = useState('');
  function handleChangeModalidade(evento: React.ChangeEvent<HTMLInputElement>){
        setModalidade(evento.target.value)
    }
  const [faixaEtaria, setFaixaEtaria] = useState('');
  function handleChangeFaixaEntaria(evento: React.ChangeEvent<HTMLInputElement>){
        setFaixaEtaria(evento.target.value)
    }
  const [contato, setContato] = useState('');
  function handleChangeContato(evento: React.ChangeEvent<HTMLInputElement>){
        setContato(evento.target.value)
    }

  // 2. Crie uma função para lidar com o envio do formulário
  const handleSubmit = (event: { preventDefault: () => void; } ) => {
    event.preventDefault(); // Impede o comportamento padrão do navegador de recarregar a página
    
    // Você pode acessar os valores dos campos aqui!
    const dadosFormulario = {
      nome,
      email,
      senha,
      endereco,
      empresa,
      modalidade,
      faixaEtaria,
      contato,
    };
    
    console.log('Dados enviados:', dadosFormulario);

    // Aqui você faria uma requisição para a sua API, por exemplo:
    // axios.post('/api/registrar', dadosFormulario);
  };



  return (
    <div className="card-page"> 
        <NavBar /> 
    <h2>Cadastro de Escolinhas</h2>
      <div className="form-container"> {/* Novo contêiner para os campos */}
        <div className="form-group">
          <label htmlFor="nome">Nome</label>
          <input type="text" id="nome" name="nome" onChange={handleChangeNome} />
        </div>
        <div className="form-group">
          <label htmlFor="email">E-mail</label>
          <input type="email" id="email" name="email" onChange={handleChangeEmail} />
        </div>
        <div className="form-group">
          <label htmlFor="senha">Senha</label>
          <input type="password" id="senha" name="senha" onChange={handleChangeSenha} />
        </div>
        
        {/* Você pode agrupar os campos 'extra' em outro contêiner ou simplesmente deixar todos no mesmo form-container */}
        <div className="form-group">
          <label htmlFor="endereco">Endereço</label>
          <input type="text" id="endereco" name="endereco"  onChange={handleChangeEndereco} />
        </div>
        <div className="form-group">
          <label htmlFor="empresa">Empresa</label>
          <input type="text" id="empresa" name="empresa"  onChange={handleChangeEmpresa}  />
        </div>
        <div className="form-group">
          <label htmlFor="modalidade">Modalidade</label>
          <input type="text" id="modalidade" name="modalidade"  onChange={handleChangeModalidade} />
        </div>
        <div className="form-group">
          <label htmlFor="faixaEtaria">Faixa Etária</label>
          <input type="text" id="faixaEtaria" name="faixaEtaria"  onChange={handleChangeFaixaEntaria} />
        </div>
        <div className="form-group">
          <label htmlFor="contato">Contato</label>
          <input type="text" id="contato" name="contato"  onChange={handleChangeContato} />
        </div>
      </div>
      <div className='send'>
        <button className="login-button" onClick={handleSubmit}>Login</button>
      </div>
    </div>
  );
}

export default RegistroForm;