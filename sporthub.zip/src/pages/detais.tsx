
function Detais(){
    return(
        <div>
            <form action="">
                <div>
                    Faça seu cadastro
                </div>
            </form>
        </div>
    )
}
export default Detais;