import React from "react";
import NavBar from "../components/NavBar";
import Footer from "../components/Footer";
import "../styles/Home.css";

const cards = [
  { title: "Futebol", img: "/src/assets/futebol.jpg" },
  { title: "Basquete", img: "/src/assets/basquete.jpg" },
  { title: "Natação", img: "/src/assets/natacao.jpg" },
  { title: "Tênis", img: "/src/assets/tenis.jpg" },
  { title: "Corrida", img: "/src/assets/corrida.jpg" },
];

const Home = () => {
  return (
    <div className="home-page">
      <NavBar />

      <div className="title">
        <h1 className="home-title">BEM-VINDO A SPORT HUB!</h1>
      </div>

      {/* Cards em vez de carrossel */}
      <div className="cards-container">
        {cards.map((card, index) => (
          <div className="card" key={index}>
            <img src={card.img} alt={card.title} className="card-image" />
            <h2 className="card-title">{card.title}</h2>
          </div>
        ))}
      </div>

      <div className="info">
        <button className="info-button">Saiba Mais</button>
      </div>

      <Footer />
    </div>
  );
};

export default Home;
